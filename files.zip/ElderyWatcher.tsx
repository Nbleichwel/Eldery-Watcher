import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, HeartPulse, AlertTriangle, Activity, AlertCircle, Pill, ShieldCheck, BatteryFull, Wifi, User, Moon, Sun } from "lucide-react";
import { motion } from "framer-motion";

export default function ElderyWatcher() {
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    // Verifica se já existe preferência salva
    const saved = localStorage.getItem("darkMode");
    if (saved === "true") setDarkMode(true);
  }, []);

  useEffect(() => {
    // Aplica ou remove a classe dark no body
    if (darkMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("darkMode", "true");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("darkMode", "false");
    }
  }, [darkMode]);

  return (
    <div className="bg-white text-gray-800 font-sans dark:bg-gray-900 dark:text-gray-100 transition-colors duration-300">
      {/* Botão de alternância */}
      <button
        className="fixed bottom-6 right-6 z-50 bg-blue-700 dark:bg-gray-800 text-white p-3 rounded-full shadow-lg hover:bg-blue-800 dark:hover:bg-gray-700 transition-colors"
        onClick={() => setDarkMode((m) => !m)}
        aria-label="Alternar modo escuro"
      >
        {darkMode ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
      </button>

      {/* Hero Section */}
      <section className="text-center py-24 px-4 bg-gradient-to-br from-blue-200 to-blue-50 dark:from-gray-800 dark:to-gray-900 shadow-inner">
        <motion.h1 initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="text-5xl font-bold mb-6 text-blue-900 dark:text-blue-300">
          Eldery Watcher
        </motion.h1>
        <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3, duration: 0.8 }} className="text-xl text-gray-700 dark:text-gray-200 mb-8 max-w-xl mx-auto">
          Monitoramento inteligente para quem você ama. Acompanhamento de saúde e localização em tempo real.
        </motion.p>
        <a href="#planos"><Button className="text-lg px-8 py-3 bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 text-white rounded-full shadow-lg">Conheça nossos planos</Button></a>
      </section>

      {/* O Conceito */}
      <section className="py-20 px-6 max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-8 text-blue-900 dark:text-blue-300">O Conceito</h2>
        <p className="text-lg text-center text-gray-700 dark:text-gray-200 max-w-3xl mx-auto">
          O Eldery Watcher é um relógio inteligente projetado para idosos, combinando monitoramento de saúde e segurança em um dispositivo elegante e fácil de usar. Desenvolvido com foco na qualidade de vida e independência, o dispositivo permite que cuidadores e familiares acompanhem remotamente os sinais vitais e a localização do usuário, proporcionando tranquilidade e cuidado contínuo.
        </p>
      </section>

      {/* Funcionalidades */}
      <section className="py-24 px-6 bg-gray-50 dark:bg-gray-800">
        <h2 className="text-4xl font-bold text-center text-blue-900 dark:text-blue-300 mb-16">Funcionalidades Avançadas</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {[
            { icon: <HeartPulse className="w-10 h-10 text-blue-700 dark:text-blue-400" />, title: "Monitoramento Cardíaco", desc: "Sensores ópticos de última geração medem continuamente a frequência cardíaca e alertam sobre irregularidades." },
            { icon: <MapPin className="w-10 h-10 text-blue-700 dark:text-blue-400" />, title: "Localização GPS em Tempo Real", desc: "Sistema de GPS integrado permite o acompanhamento em tempo real com histórico de rotas e zonas seguras." },
            { icon: <AlertTriangle className="w-10 h-10 text-blue-700 dark:text-blue-400" />, title: "Detector de Quedas", desc: "Sensores de movimento detectam quedas automaticamente e enviam alertas para contatos de emergência." },
            { icon: <Activity className="w-10 h-10 text-blue-700 dark:text-blue-400" />, title: "Monitoramento de Atividade Física", desc: "Acompanhamento de passos, distância e calorias, adaptado às capacidades do usuário." },
            { icon: <AlertCircle className="w-10 h-10 text-blue-700 dark:text-blue-400" />, title: "Botão SOS", desc: "Com um toque, envia um alerta com localização para contatos cadastrados." },
            { icon: <Pill className="w-10 h-10 text-blue-700 dark:text-blue-400" />, title: "Lembretes de Medicação", desc: "Alertas configuráveis para medicamentos, consultas e tarefas diárias." },
          ].map(({ icon, title, desc }, i) => (
            <Card key={i} className="hover:shadow-2xl transition-shadow duration-300 dark:bg-gray-900 dark:border-gray-700">
              <CardContent className="p-6">
                <div className="mb-4">{icon}</div>
                <h3 className="text-xl font-semibold mb-2 text-blue-800 dark:text-blue-200">{title}</h3>
                <p className="text-gray-600 dark:text-gray-300">{desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Tecnologia de Ponta */}
      <section className="py-24 px-6 bg-white dark:bg-gray-900">
        <h2 className="text-4xl font-bold text-center text-blue-900 dark:text-blue-300 mb-12">Tecnologia de Ponta</h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <Card><CardContent className="p-6 text-center">
            <ShieldCheck className="w-10 h-10 text-blue-700 dark:text-blue-400 mb-4 mx-auto" />
            <h3 className="text-xl font-semibold mb-2 text-blue-800 dark:text-blue-200">Segurança de Dados</h3>
            <p className="text-gray-600 dark:text-gray-300">Sistema com criptografia de nível hospitalar garante confidencialidade das informações.</p>
          </CardContent></Card>
          <Card><CardContent className="p-6 text-center">
            <BatteryFull className="w-10 h-10 text-blue-700 dark:text-blue-400 mb-4 mx-auto" />
            <h3 className="text-xl font-semibold mb-2 text-blue-800 dark:text-blue-200">72h de Bateria</h3>
            <p className="text-gray-600 dark:text-gray-300">Longa duração com carregamento magnético sem conectores complicados.</p>
          </CardContent></Card>
          <Card><CardContent className="p-6 text-center">
            <Wifi className="w-10 h-10 text-blue-700 dark:text-blue-400 mb-4 mx-auto" />
            <h3 className="text-xl font-semibold mb-2 text-blue-800 dark:text-blue-200">Precisão de Sinais</h3>
            <p className="text-gray-600 dark:text-gray-300">Sensores e GPS com precisão mesmo em ambientes internos.</p>
          </CardContent></Card>
        </div>
      </section>

      {/* Aplicativo Conectado */}
      <section className="py-24 px-6 bg-gray-50 dark:bg-gray-800">
        <h2 className="text-4xl font-bold text-center text-blue-900 dark:text-blue-300 mb-12">Aplicativo Conectado</h2>
        <p className="text-lg text-center text-gray-700 dark:text-gray-200 max-w-4xl mx-auto">
          O Eldery Watcher se integra a um aplicativo intuitivo que permite o acompanhamento em tempo real dos sinais vitais, localização, histórico de atividades e alertas. Configurações personalizáveis garantem privacidade e adaptabilidade a cada usuário.
        </p>
      </section>

      {/* Planos */}
      <section id="planos" className="py-24 px-6 bg-white dark:bg-gray-900">
        <h2 className="text-4xl font-bold text-center text-blue-900 dark:text-blue-300 mb-16">Nossos Planos</h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {[
            { nome: "Plano Essencial", preco: "R$ 79/mês", recursos: ["Monitoramento cardíaco", "Localização GPS", "Botão SOS"] },
            { nome: "Plano Conforto", preco: "R$ 109/mês", recursos: ["Todos os do Essencial", "Detector de quedas", "Lembretes de medicação"] },
            { nome: "Plano Premium", preco: "R$ 149/mês", recursos: ["Todos os anteriores", "Relatórios médicos completos", "Suporte 24h"] },
          ].map(({ nome, preco, recursos }, i) => (
            <Card key={i} className="shadow-md hover:shadow-xl transition-shadow dark:bg-gray-900 dark:border-gray-700">
              <CardContent className="p-6 text-center">
                <h3 className="text-2xl font-bold text-blue-800 dark:text-blue-200 mb-2">{nome}</h3>
                <p className="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-4">{preco}</p>
                <ul className="text-gray-600 dark:text-gray-300 space-y-2">
                  {recursos.map((r, idx) => <li key={idx}>✓ {r}</li>)}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Galeria */}
      <section className="py-24 px-6 bg-gray-50 dark:bg-gray-800">
        <h2 className="text-4xl font-bold text-center text-blue-900 dark:text-blue-300 mb-16">Galeria do Produto</h2>
        <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          <img src="/images/relgio-frontal.jpg" alt="Vista Frontal" className="rounded-xl shadow-md" />
          <img src="/images/relgio-traseiro.jpg" alt="Vista Traseira" className="rounded-xl shadow-md" />
        </div>
      </section>

      {/* Depoimentos */}
      <section className="py-24 px-6 bg-white dark:bg-gray-900">
        <h2 className="text-4xl font-bold text-center text-blue-900 dark:text-blue-300 mb-16">Histórias de Quem Usa</h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <Card><CardContent className="p-6">
            <p className="italic text-gray-700 dark:text-gray-200 mb-4">"Desde que comecei a usar o Eldery Watcher, meus filhos ficam mais tranquilos e eu me sinto mais segura para continuar minhas caminhadas diárias no parque."</p>
            <p className="text-blue-800 dark:text-blue-200 font-semibold">Maria Helena, 78 anos</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">Usuária</p>
          </CardContent></Card>
          <Card><CardContent className="p-6">
            <p className="italic text-gray-700 dark:text-gray-200 mb-4">"Como filho único e morando em outra cidade, o Eldery Watcher me trouxe uma paz de espírito que não tinha antes."</p>
            <p className="text-blue-800 dark:text-blue-200 font-semibold">Carlos Eduardo, 52 anos</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">Filho de usuária</p>
          </CardContent></Card>
          <Card><CardContent className="p-6">
            <p className="italic text-gray-700 dark:text-gray-200 mb-4">"O Eldery Watcher facilita o acompanhamento remoto de pacientes idosos e melhora a prevenção de crises clínicas."</p>
            <p className="text-blue-800 dark:text-blue-200 font-semibold">Dra. Ana Moreira, 41 anos</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">Médica Geriatra</p>
          </CardContent></Card>
        </div>
      </section>

      {/* Fundadores */}
      <section className="py-24 px-6 bg-blue-50 dark:bg-gray-800">
        <h2 className="text-4xl font-bold text-center text-blue-900 dark:text-blue-300 mb-16">Nossos Fundadores</h2>
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto text-center">
          {["Nicolas Bleichwel", "Kawe Warakoski"].map((name, idx) => (
            <Card key={idx} className="hover:shadow-xl dark:bg-gray-900 dark:border-gray-700">
              <CardContent className="p-6">
                <User className="w-16 h-16 text-blue-700 dark:text-blue-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-blue-800 dark:text-blue-200">{name}</h3>
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="mt-12 text-center text-gray-600 dark:text-gray-400 text-sm">
          Ana Julia De Deus • Nicole Kunzler • Bruno Cassiano • Gustavo Vedoy
        </div>
      </section>

      {/* Contato */}
      <section className="py-24 px-6 bg-white dark:bg-gray-900">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6 text-blue-900 dark:text-blue-300">Fale Conosco</h2>
          <p className="text-lg mb-2">📍 Av. Paulista, 1000 - São Paulo, SP</p>
          <p className="text-lg mb-2">📞 +55 11 3456-7890</p>
          <p className="text-lg mb-2">📧 contato@elderywatcher.com.br</p>
          <div className="flex justify-center gap-6 mt-6 text-blue-700 dark:text-blue-400">
            <a href="#">Instagram</a>
            <a href="#">Facebook</a>
            <a href="#">LinkedIn</a>
          </div>
        </div>
      </section>

      <footer className="text-center py-4 bg-blue-100 dark:bg-gray-950 text-sm text-blue-900 dark:text-blue-300">
        © 2025 Eldery Watcher. Todos os direitos reservados.
      </footer>
    </div>
  );
}