import ElderyWatcher from '@/components/ElderyWatcher';

export default function Home() {
  return <ElderyWatcher />;
}